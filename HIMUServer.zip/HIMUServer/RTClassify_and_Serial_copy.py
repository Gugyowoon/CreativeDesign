# realtime_classifier.py
import pandas as pd
import pickle
import serial
import time
from sklearn.ensemble import RandomForestClassifier
from HIMUServer import HIMUServer


# Arduino와 통신할 때 사용할 포트
port = '/dev/ttyACM0'  # 포트는 Arduino가 연결된 포트로 변경해야 함
baud_rate = 9600

# 시리얼 포트 초기화
arduino = serial.Serial(port, baud_rate)
time.sleep(2)  # 포트가 초기화될 동안 잠시 기다림

# try:
#     while True:
#         # Arduino로 전송할 데이터
#         data_to_send = input("Arduino로 전송할 데이터 입력: ")
        
#         # 데이터를 Arduino로 전송
#         arduino.write(data_to_send.encode())
        
#         # Arduino에서의 응답을 받아서 출력
#         while arduino.in_waiting:
#             print("Arduino로부터 받은 데이터:", arduino.readline().decode().strip())
            
# except KeyboardInterrupt:
#     # 사용자가 Ctrl+C를 눌렀을 때 프로그램 종료
#     print("프로그램 종료")
#     arduino.close()  # 시리얼 포트 닫기


# 학습된 모델 불러오기
with open('random_forest_model.pkl', 'rb') as f:
    clf = pickle.load(f)

# 사용하는 feature정보 
feature_cols = ['Sensor1_X', 'Sensor1_Y', 'Sensor1_Z', 'Sensor2_X', 'Sensor2_Y', 'Sensor2_Z']

class RealTimeClassifier:
    def __init__(self, serverInstance):
        #super().__init__(serverInstance)
        self.__server = serverInstance
        self.previous_data = None
        self.previous_label = None 

    def notify(self, sensor_data):
        if not sensor_data:
            #print("No sensor data received!")
            return 
        
        # print(sensor_data) # 현재 데이터 출력
        sensor1_data = [float(x) for x in sensor_data[0][0]]
        sensor2_data = [float(x) for x in sensor_data[0][1]]

        if self.previous_data is not None:
            sensor1_diff = [curr - prev for curr, prev in zip(sensor1_data, self.previous_data[0])]
            sensor2_diff = [curr - prev for curr, prev in zip(sensor2_data, self.previous_data[1])]
            
            input_data = sensor1_diff + sensor2_diff
            input_df = pd.DataFrame([input_data], columns=feature_cols)
            
            predicted_label = clf.predict(input_df)[0]

            if predicted_label == self.previous_label: # 여기서부터 추가됨 
                self.repeat_count +=1 #
            else: #
                self.repeat_count = 1 #
                self.previous_label = predicted_label #
            
            if self.repeat_count == 2: # 여기까지 추가됨 
                # print(f"Predicted Movement: {predicted_label[0]}") 
                arduino.write(predicted_label[0].encode())
                # 데이터를 Arduino로 전송
                #predicted_label[0] : U, D , L, R, K 중 하나 출력 
            
        self.previous_data = (sensor1_data, sensor2_data) # 데이터 계속 갱신 

#HIMUServer instance:
myHIMUServer = HIMUServer()

# 실시간 분류기 인스턴스 생성 및 서버에 추가
realtime_classifier = RealTimeClassifier(myHIMUServer)
myHIMUServer.addListener(realtime_classifier)

# 타임아웃 시간 설정 (1초 단위)
myHIMUServer.timeout = 2


try:
    # 포트 2055번으로, TCP프로토콜로 통신 시작
    myHIMUServer.start("TCP", 2055)
finally:
    arduino.close()  # 시리얼 포트를 항상 닫도록 수정