import os
import csv
import numpy as np

def process_csv_files(directory):
    for filename in os.listdir(directory):
        if filename.endswith(".csv") and filename.startswith("Keep"):
            file_path = os.path.join(directory, filename)
            output_file_path = os.path.join(directory, f"processed_{filename}")
            
            with open(file_path, 'r') as file, open(output_file_path, 'w', newline='') as output_file:
                csv_reader = csv.reader(file)
                csv_writer = csv.writer(output_file)
                
                # Write the header row to the output file
                header = next(csv_reader)
                csv_writer.writerow(header)
                
                prev_row = None
                for row in csv_reader:
                    if prev_row is not None:
                        # Calculate the difference between the current row and the previous row
                        diff_row = [row[0]]  # Keep the timestamp column unchanged
                        diff_row.extend([str(float(curr) - float(prev)) for curr, prev in zip(row[1:], prev_row[1:])])
                        csv_writer.writerow(diff_row)
                    
                    prev_row = row

# Directory containing the CSV files
directory = '/home/capston/IMU/HIMUServer/sensorData'

# Process the CSV files
process_csv_files(directory)