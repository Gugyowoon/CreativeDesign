import pandas as pd
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# CSV 파일 경로
file_path = "/home/capston/IMU/HIMUServer/sensorData/processed/new_merged/Final_merged/Result/ALL_merged_file_2.csv" 

# CSV 파일 읽기
data = pd.read_csv(file_path, header=0)  # header=0을 추가하여 첫 번째 행을 열 이름으로 사용

# 특성(X)과 레이블(y) 분리
# 열 이름을 직접 지정하거나, data.columns를 사용하여 열 이름 목록을 가져올 수 있습니다.
feature_cols = ['Sensor1_X', 'Sensor1_Y', 'Sensor1_Z', 'Sensor2_X', 'Sensor2_Y', 'Sensor2_Z']
X = data[feature_cols]
y = data['label']

# 데이터 분할 (훈련 세트와 테스트 세트)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 랜덤 포레스트 분류기 생성
clf = RandomForestClassifier(n_estimators=100, random_state=42)

# 모델 학습
clf.fit(X_train, y_train)

# 테스트 세트 예측
y_pred = clf.predict(X_test)


# 모델 성능 평가
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)


with open('random_forest_model.pkl', 'wb') as f:
    pickle.dump(clf, f)
    
# 더미 데이터 예측
left_dummy_data = pd.DataFrame({'Sensor1_X': [0.034], 
                                'Sensor1_Y': [0.012],
                                'Sensor1_Z': [0.034], 
                                'Sensor2_X': [0.032], 
                                'Sensor2_Y': [0.510], 
                                'Sensor2_Z': [0.036]})
#left_dummy_data = [[0.034, 0.012, 0.034, 0.032, 0.510, 0.036]] #LEFT
#right_dummy_data = [[-0.000, 0.009, 0.001, 0.018, 0.030,  0.035]] #RIGHT
#up_dummy_data = [[-0.014, -0.017, -0.007, -0.002, -0.019, -0.008]] #UP
#down_dummy_data = [[-0.028, -0.002, 0.002, -0.022, -0.003, 0.021]] #DOWN

predicted_movement = clf.predict(left_dummy_data)
print("Predicted Movement 1:", predicted_movement)

# predicted_movement = clf.predict(right_dummy_data)
# print("Predicted Movement 2:", predicted_movement)

# predicted_movement = clf.predict(up_dummy_data)
# print("Predicted Movement 3:", predicted_movement)

# predicted_movement = clf.predict(down_dummy_data)
# print("Predicted Movement 4:", predicted_movement)