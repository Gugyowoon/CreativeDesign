import pandas as pd
import numpy as np
from sklearn.discriminant_analysis import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import tensorflow as tf
import pickle

# CSV 파일 경로
file_path = '/home/capston/IMU/HIMUServer/sensorData_ver2/Result/ALL_merged_file1.csv'

# CSV 파일 읽기
data = pd.read_csv(file_path, header=0)

# 특성과 레이블 분리
features = data.drop(columns=['label'])
labels = data['label']

# 레이블 인코딩 (문자열을 정수로 변환)
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels)


# 학습 및 테스트 세트로 분할 ; X is for train , Y is for test 
X_train, X_test, y_train, y_test = train_test_split(features, encoded_labels, test_size=0.2, random_state=42)

# 정규화
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 피처 이름 저장
with open('/home/capston/IMU/HIMUServer/feature_columns.pkl', 'wb') as f:
    pickle.dump(X_train.columns.tolist(), f)

# # 시차 특성 추가 (이전 1개 시차)해서 모델을 학습시킴 
# def create_lag_features(df, lag=1):
#     lagged_df = df.copy()
#     for i in range(1, lag + 1):
#         lagged = df.shift(i)
#         lagged.columns = [f"{col}_lag{i}" for col in df.columns]
#         lagged_df = pd.concat([lagged_df, lagged], axis=1)
#     lagged_df.dropna(inplace=True)
#     return lagged_df

# # 시차 특성을 생성한 후 데이터프레임에 반영
# X_train_lagged = create_lag_features(pd.DataFrame(X_train_scaled, columns=features.columns), lag=1)
# X_test_lagged = create_lag_features(pd.DataFrame(X_test_scaled, columns=features.columns), lag=1)

# # y_train과 y_test를 시차 특성에 맞게 조정
# y_train_lagged = y_train[-len(X_train_lagged):]
# y_test_lagged = y_test[-len(X_test_lagged):]

# # 길이 일치 확인
# print(f"X_train_scaled shape: {X_train_scaled.shape}, y_train_scaled length: {len(y_train_scaled)}")
# print(f"X_test_scaled shape: {X_test_scaled.shape}, y_test_lagged length: {len(y_test_lagged)}")



# LSTM 모델 학습
X_train_lstm = X_train_scaled.reshape(X_train_scaled.shape[0], 1, X_train_scaled.shape[1])
X_test_lstm = X_test_scaled.reshape(X_test_scaled.shape[0], 1, X_test_scaled.shape[1])

model_lstm = Sequential()
model_lstm.add(LSTM(50, activation='relu', input_shape=(X_train_lstm.shape[1], X_train_lstm.shape[2])))
model_lstm.add(Dropout(0.2))
model_lstm.add(Dense(len(np.unique(y_train)), activation='softmax'))

model_lstm.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model_lstm.fit(X_train_lstm, y_train, epochs=50, batch_size=32, validation_split=0.2, verbose=1)
# LSTM 모델 저장
model_lstm.save('lstm_model.h5')


# RandomForest 모델 학습
model_rf = RandomForestClassifier(n_estimators=100, random_state=42)
model_rf.fit(X_train_scaled, y_train)

# 모델 저장

with open('random_forest_model.pkl', 'wb') as f:
    pickle.dump(model_rf, f)
with open('label_encoder.pkl', 'wb') as f:
    pickle.dump(label_encoder, f)
# 인코더 저장
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
