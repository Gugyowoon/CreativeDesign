import serial
import time

ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
time.sleep(2)  # 아두이노 초기화 시간

try:
    ser.write(b'Hello Arduino\n')
    print(ser.readline().decode('utf-8').strip())
finally:
    ser.close()
