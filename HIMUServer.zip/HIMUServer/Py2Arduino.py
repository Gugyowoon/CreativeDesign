import serial
import time

# Arduino와 통신할 때 사용할 포트
port = '/dev/ttyACM0'  # 포트는 Arduino가 연결된 포트로 변경해야 함
baud_rate = 9600

# 시리얼 포트 초기화
arduino = serial.Serial(port, baud_rate)
time.sleep(2)  # 포트가 초기화될 동안 잠시 기다림

try:
    while True:
        # Arduino로 전송할 데이터
        data_to_send = input("Arduino로 전송할 데이터 입력: ")
        
        # 데이터를 Arduino로 전송
        arduino.write(data_to_send.encode())
        
        # Arduino에서의 응답을 받아서 출력
        while arduino.in_waiting:
            print("Arduino로부터 받은 데이터:", arduino.readline().decode().strip())
            
except KeyboardInterrupt:
    # 사용자가 Ctrl+C를 눌렀을 때 프로그램 종료
    print("프로그램 종료")
    arduino.close()  # 시리얼 포트 닫기

'''
import serial
import time

# 시리얼 포트 설정
ser = serial.Serial('/dev/ttyACM0', 9600)
time.sleep(2)  # 아두이노가 재시작하는 것을 대기합니다.

try:
    while True:
        # 전송할 데이터
        data = "Hello Arduino!"
        ser.write(data.encode())  # 데이터를 바이트로 인코딩하여 전송합니다.
        time.sleep(1)  # 데이터를 보낸 후 잠시 대기합니다.
except KeyboardInterrupt:
    print("Program terminated!")
finally:
    ser.close()  # 시리얼 포트를 안전하게 닫습니다.

'''


'''
import serial 
import time 

# Setting the serial port 
#ser = serial.Serial('COM3', 9600, timeout=1)
ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
time.sleep(2)

data = "Hello, Arduino?"

# Send data after encoding 
ser.write(data.encode())

# Get rsp from arduino 
response = ser.readline().decode().strip()
print("Received from Arduino", response)

# Close serial connection 
ser.close()
'''
