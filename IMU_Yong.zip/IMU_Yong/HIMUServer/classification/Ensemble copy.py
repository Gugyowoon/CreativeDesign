'''
dataVer3 의 앙상블 학습용
'''

import pandas as pd
import numpy as np
from sklearn.discriminant_analysis import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import tensorflow as tf
import pickle

# CSV 파일 경로
#file_path = 'C:\\Users\wjstk\Downloads\HIMUServer\HIMUServer\sensorData_ver3\Result\ALL_merged_file1.csv'
file_path = '/home/capston/IMU_Yong/HIMUServer/sensorData_ver3/Result/ALL_merged_file1.csv'

# CSV 파일 읽기
data = pd.read_csv(file_path, header=0)

# 특성과 레이블 분리
features = data.drop(columns=['label'])
labels = data['label']


# 레이블 인코딩 (문자열을 정수로 변환)
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels)


# 학습 및 테스트 세트로 분할 ; X is for train , Y is for test 
X_train, X_test, y_train, y_test = train_test_split(features, encoded_labels, test_size=0.2, random_state=42)


# LSTM 모델 학습
X_train_lstm = X_train.values.reshape(X_train.shape[0], 1, X_train.shape[1])
X_test_lstm = X_test.values.reshape(X_test.shape[0], 1, X_test.shape[1])

model_lstm = Sequential()
model_lstm.add(LSTM(50, activation='relu', input_shape=(X_train_lstm.shape[1], X_train_lstm.shape[2])))
model_lstm.add(Dropout(0.2))
model_lstm.add(Dense(len(np.unique(y_train)), activation='softmax'))

model_lstm.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model_lstm.fit(X_train_lstm, y_train, epochs=50, batch_size=32, validation_split=0.2, verbose=1)
# LSTM 모델 저장
model_lstm.save('lstm_model_ver2_my.h5')


# RandomForest 모델 학습
model_rf = RandomForestClassifier(n_estimators=100, random_state=42)
model_rf.fit(X_train, y_train)

# 모델 저장

with open('random_forest_model_ver2_my.pkl', 'wb') as f:
    pickle.dump(model_rf, f)
with open('label_encoder.pkl', 'wb') as f:
    pickle.dump(label_encoder, f)
# 인코더 저장
