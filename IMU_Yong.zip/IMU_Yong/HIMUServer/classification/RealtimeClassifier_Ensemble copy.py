import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from tensorflow import keras
from keras.models import load_model
#from tensorflow.keras.models import load_model
from sklearn.ensemble import RandomForestClassifier
import pickle
from HIMUServer import HIMUServer


# 학습된 모델 불러오기
#lstm_model = load_model('/home/capston/IMU_Yong/HIMUServer/lstm_model_ver1.h5', compile=False) # 경로 주의 , lstm_model_ver1.pkl
try:
    lstm_model = load_model('/home/capston/IMU_Yong/HIMUServer/lstm_model_ver2_my.h5', compile=False)
except TypeError as e:
    print(f"Error loading LSTM model: {e}")
    # Handle the error or consider converting the model


with open('/home/capston/IMU_Yong/HIMUServer/random_forest_model_ver2_my.pkl', 'rb') as f: # 경로 주의, random_forest_ver1.pkl
    rf_model = pickle.load(f)
with open('/home/capston/IMU_Yong/HIMUServer/label_encoder.pkl', 'rb') as f:
    label_encoder = pickle.load(f)
# with open('/home/capston/IMU_Yong/HIMUServer/scaler.pkl', 'rb') as f:
#     scaler = pickle.load(f)    


feature_cols = ['Sensor1_X', 'Sensor1_Y', 'Sensor1_Z', 
                'Sensor2_X', 'Sensor2_Y', 'Sensor2_Z',
                'Sensor3_X', 'Sensor3_Y', 'Sensor3_Z',
                'Sensor4_X', 'Sensor4_Y', 'Sensor4_Z']

               
# 실시간 분류기를 위한 클래스
class RealTimeClassifier:
    def __init__(self, serverInstance):
        self.__server = serverInstance
        self.previous_data = None

    
    def notify(self, sensor_data):
        if not sensor_data or len(sensor_data[0]) < 4:
            #print("Invalid sensor data received")
            return

        #print(sensor_data)
        
        try:
            sensor1_data = [float(x) for x in sensor_data[0][0]]
            sensor2_data = [float(x) for x in sensor_data[0][1]]
            sensor3_data = [float(x) for x in sensor_data[0][2]]
            sensor4_data = [float(x) for x in sensor_data[0][3]]
        except IndexError as e:
            print(f"IndexError: {e}")
            return
        except ValueError as e:
            print(f"ValueError: {e}")
            return

        if self.previous_data is not None:
            try:
                sensor1_diff = [curr - prev for curr, prev in zip(sensor1_data, self.previous_data[0])]
                sensor2_diff = [curr - prev for curr, prev in zip(sensor2_data, self.previous_data[1])]
                sensor3_diff = [curr - prev for curr, prev in zip(sensor3_data, self.previous_data[2])]
                sensor4_diff = [curr - prev for curr, prev in zip(sensor4_data, self.previous_data[3])]
           
            except IndexError as e:
                print(f"IndexError in differencing: {e}")
                return

            input_data = sensor1_diff + sensor2_diff + sensor3_diff + sensor4_diff
            
            input_df = pd.DataFrame([input_data], columns=feature_cols)

            # 정규화
            #input_df = pd.DataFrame(scaler.transform(input_df), columns=feature_cols)

            # # 피처 이름 일치시키기
            # input_df = input_df.reindex(columns=feature_cols, fill_value=0)

            # LSTM 모델 입력 형식으로 데이터 변환
            input_data_lstm = input_df.values.reshape(1, 1, input_df.shape[1])

            # LSTM 모델 예측 확률
            y_pred_lstm_prob = lstm_model.predict(input_data_lstm)

            # RandomForest 모델 예측 확률
            y_pred_rf_prob = rf_model.predict_proba(input_df)

            # 소프트 보팅을 통한 앙상블
            y_pred_ensemble_prob = (y_pred_lstm_prob + y_pred_rf_prob) / 2
            y_pred_ensemble_classes = np.argmax(y_pred_ensemble_prob, axis=1)

            # 레이블 인코딩 복원
            predicted_label = label_encoder.inverse_transform(y_pred_ensemble_classes)

            print(f"Predicted Movement: {predicted_label[0]}")

        self.previous_data = (sensor1_data, sensor2_data, sensor3_data, sensor4_data)
       


# HIMUServer instance:
myHIMUServer = HIMUServer()

# 실시간 분류기 인스턴스 생성 및 서버에 추가
realtime_classifier = RealTimeClassifier(myHIMUServer)
myHIMUServer.addListener(realtime_classifier)

# Change the timeout (in seconds):
myHIMUServer.timeout = 4

# Launch acquisition via TCP on port 2055:
myHIMUServer.start("TCP", 2055)