
import csv
from datetime import datetime
from HIMUServer import HIMUServer

#An example of listener implementation.
class SimplePrintListener:
    def __init__(self, serverInstance, output_file):
        self.__server = serverInstance
        self.output_file = output_file
        self.csv_file = open(self.output_file, mode='w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(['Sensor1_X', 'Sensor1_Y', 'Sensor1_Z',
                                  'Sensor2_X', 'Sensor2_Y', 'Sensor2_Z',
                                  'Sensor3_X', 'Sensor3_Y', 'Sensor3_Z',
                                   'Sensor4_X', 'Sensor4_Y', 'Sensor4_Z'])

    def notify(self, sensorData):
        if not sensorData:
            # If sensorData is empty, skip processing
            return

        print(sensorData)
        for data in sensorData:
            converted_data = []
            for sublist in data:
                converted_sublist = HIMUServer.strings2Floats(sublist)
                converted_data.extend(converted_sublist)

            if len(converted_data) >= 12:
                # Extract the relevant sensor values
                sensor1_data = converted_data[:3]
                sensor2_data = converted_data[3:6]
                sensor3_data = converted_data[6:9]
                sensor4_data = converted_data[9:12]

                # Get the current timestamp
                #timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")

                # Write the sensor data to the CSV file
                #self.csv_writer.writerow([timestamp] + sensor1_data + sensor2_data)
                self.csv_writer.writerow( sensor1_data + sensor2_data + sensor3_data + sensor4_data)

    def __del__(self):
        self.csv_file.close()

# Output CSV file path
output_file = './sensorData_ver4_1000ms/test1.csv'

#HIMUServer instance:
myHIMUServer = HIMUServer()


#Creating listener and adding it to the server instance:
myListener = SimplePrintListener(myHIMUServer, output_file)
#myListener = SimplePrintListener(myHIMUServer)
myHIMUServer.addListener(myListener)

#Change the timeout (in seconds) :
myHIMUServer.timeout = 2

#Launch acquisition via TCP on port 2055:
myHIMUServer.start("TCP", 2055)

#Launch acquisition via UDP on port 2055:
#myHIMUServer.start("UDP", 2055)

#Launch acquisition from local file:
#myHIMUServer.start("FILE", "HIMU-filetest.csv")
