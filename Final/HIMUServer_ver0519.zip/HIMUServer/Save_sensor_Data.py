
import csv
from HIMUServer import HIMUServer


#An example of listener implementation.
class SimplePrintListener:
    def __init__(self, serverInstance, output_file):
        self.__server = serverInstance
        self.output_file = output_file
        self.csv_file = open(self.output_file, mode='w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow(['Sensor1_X', 'Sensor1_Y', 'Sensor1_Z'])
                                #   'Sensor2_X', 'Sensor2_Y', 'Sensor2_Z'
                                #   'Sensor3_X', 'Sensor3_Y', 'Sensor3_Z',
                                #    'Sensor4_X', 'Sensor4_Y', 'Sensor4_Z'])

   
    def notify(self, sensorData):
        if not sensorData:
            return
        
        print(sensorData)
        # 모든 값을 float으로 변환 ; 기존에는 str이였음 
#        sensorData_float = [[[float(value) for value in sublist] for sublist in subsublist] for subsublist in sensorData]

        # Sensor1 = sensorData_float[0][0]
        # Sensor2 = sensorData_float[0][1]
        # Sensor3 = sensorData_float[0][2]
        # Sensor4 = sensorData_float[0][3] # 각 센서의 데이터를 float 형태로 가지고 있는 리스트들 
        
#        print(sensorData_float)
        

#       sensor1_data = sensorData_float[0][0][:3]
        #print(sensor1_data)
#        self.csv_writer.writerow( sensor1_data1)
        # for data in sensorData:
        #     converted_data = []
        #     for sublist in data:
        #         converted_sublist = HIMUServer.strings2Floats(sublist)
        #         converted_data.extend(converted_sublist)

        #     if len(converted_data) >= 3: # 데이터 길이 = 센서 수 *3 
        #         # Extract the relevant sensor values
        #         sensor1_data = converted_data[:3]
        #         #sensor2_data = converted_data[3:6]
        #         #sensor3_data = converted_data[6:9]
        #         #sensor4_data = converted_data[9:12]
        #         # Write the sensor data to the CSV file
        #         #self.csv_writer.writerow( sensor1_data + sensor2_data + sensor3_data + sensor4_data)
        #         self.csv_writer.writerow( sensor1_data)
        

    def __del__(self):
        self.csv_file.close()

# Output CSV file path
output_file = 'HIMUServer/SamsungOrient/check_2022.csv'

#HIMUServer instance:
myHIMUServer = HIMUServer()


#Creating listener and adding it to the server instance:
#myListener = SimplePrintListener(myHIMUServer, output_file)
myListener = SimplePrintListener(myHIMUServer, output_file)
myHIMUServer.addListener(myListener)

#Change the timeout (in seconds) :
myHIMUServer.timeout = 2

#Launch acquisition via TCP on port 2055:
myHIMUServer.start("TCP", 2055)

#Launch acquisition via UDP on port 2055:
#myHIMUServer.start("UDP", 2055)

#Launch acquisition from local file:
#myHIMUServer.start("FILE", "HIMU-filetest.csv")
