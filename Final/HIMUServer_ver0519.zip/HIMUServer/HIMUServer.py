import socket
import math
import traceback

valuesPerSensor = 3

class HIMUServer:

    def __init__(self, bufferSize=2048, timeout=10, separatorIndex=0):
        self.__listeners = []
        self.__packSeparators = ["\r\n", "#"]
        self.__commentSymbol = '@'
        self.timeout = timeout  # timeout in seconds
        self.bufferSize = bufferSize  # bytes
        self.go = True
        self.previous_data = ""  # 이전 데이터를 저장할 변수
        self.previous_label = None  # 추가됨 0514
        self.repeat_count = 0  # 추가됨 0514

        if separatorIndex == 0:
            self.packSeparator = self.__packSeparators[0]
        else:
            self.packSeparator = self.__packSeparators[separatorIndex]

    def addListener(self, newListener):
        self.__listeners.append(newListener)

    def __notifyListeners(self, recPacket):
        for listener in self.__listeners:
            listener.notify(recPacket)

    def executeTCP(self, port, raw=False):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        serverAddress = ('', port)
        sock.bind(serverAddress)
        sock.listen(1)
        print('waiting for connection...')
        [connection, clientAddress] = sock.accept()
        connection.setblocking(1)
        print('connection from ' + str(clientAddress))
        while self.go:
            data = connection.recv(self.bufferSize)
            if not data:
                break
            full_data = self.previous_data + data.decode('utf-8')  # 이전 데이터와 현재 수신된 데이터를 합침
            #print(f"Raw data received: {full_data}")  # 수신된 원본 데이터를 출력

            if raw:
                self.__notifyListeners(full_data)
            else:
                if self.packSeparator in full_data:  # 패킷이 완전한 경우
                    packets = full_data.split(self.packSeparator)
                    for packet in packets[:-1]:
                        self.__notifyListeners(self.__extractSensorData(packet))
                    self.previous_data = packets[-1]  # 마지막 패킷을 저장
                else:
                    self.previous_data = full_data  # 데이터가 불완전하면 저장

        connection.close()

    def executeUDP(self, port, raw=False):
        UDPSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        UDPSocket.settimeout(self.timeout)
        serverAddress = ('', port)
        print('Listening on port ' + str(port))
        UDPSocket.bind(serverAddress)
        while self.go:
            [data, attr] = UDPSocket.recvfrom(self.bufferSize)
            if not data:
                break
            full_data = self.previous_data + data.decode('utf-8')  # 이전 데이터와 현재 수신된 데이터를 합침
            #print(f"Raw data received: {full_data}")  # 수신된 원본 데이터를 출력

            if raw:
                self.__notifyListeners(full_data)
            else:
                if self.packSeparator in full_data:  # 패킷이 완전한 경우
                    packets = full_data.split(self.packSeparator)
                    for packet in packets[:-1]:
                        self.__notifyListeners(self.__extractSensorData(packet))
                    self.previous_data = packets[-1]  # 마지막 패킷을 저장
                else:
                    self.previous_data = full_data  # 데이터가 불완전하면 저장

        UDPSocket.close()

    def executeFile(self, fileName, raw=False):
        print("Reading file " + fileName + " ...")
        with open(fileName, 'r') as f:
            sline = f.readline()
            while sline != '':
                if sline[0] != self.__commentSymbol:
                    if raw:
                        self.__notifyListeners(sline)
                    else:
                        self.__notifyListeners(self.__extractSensorData(sline))
                sline = f.readline()
        print('reached EOF.')

    @staticmethod
    def strings2Floats(data):
        out = []
        if isinstance(data, list):
            for item in data:
                if item != '':
                    out.append(float(item))
        elif isinstance(data, str):
            for item in data.split(','):
                if item != '':
                    out.append(float(item))
        return out

    @staticmethod
    def printSensorsData(sensorData):
        try:
            for acquisition in sensorData:
                i = 1
                for sensorAcq in acquisition:
                    print('Sensor' + str(i) + ": " + str(sensorAcq))
                    i += 1
        except Exception as ex:
            print(str(ex))

    def __extractSensorData(self, dataString):
        #print(f"Data string before processing: {dataString}")  # 원본 데이터 문자열 출력
        packages = dataString.split(self.packSeparator)
        retVal = []
        for pack in packages:
            if pack:
                try:
                    packVal = []
                    packSplit = pack.replace('\n', '').replace('\r', '').split(",")
                    numSensors = int(math.floor(len(packSplit) / valuesPerSensor))
                    for i in range(numSensors):
                        p = packSplit[i * valuesPerSensor: (i + 1) * valuesPerSensor]
                        packVal.append(p)
                    if len(packVal) > 0:
                        retVal.append(packVal)
                except Exception as ex:
                    print(str(ex))
        return retVal

    def start(self, protocol, arg, raw=False):
        print('protocol: ' + protocol)
        print('RAW: ' + ('yes' if raw else 'no'))
        try:
            if protocol == 'RAW':
                print("RAW deprecated, use the <raw> parameter instead.")
            elif protocol == 'UDP':
                self.executeUDP(int(arg), raw)
            elif protocol == 'TCP':
                self.executeTCP(int(arg), raw)
            elif protocol == 'FILE':
                self.executeFile(arg, raw)
        except Exception as ex:
            print(str(ex))

    def stop(self):
        self.go = False
