# import tensorflow as tf
# from tensorflow.keras.models import load_model

# # Load with older version
# model = load_model('/home/capston/IMU_Yong/HIMUServer/lstm_model_ver1.h5', compile=False)

# # Save with the current version
# model.save('/home/capston/IMU_Yong/HIMUServer/lstm_model_ver1_converted.h5')

from tensorflow.keras.models import load_model

try:
    lstm_model = load_model('/home/capston/IMU_Yong/HIMUServer/lstm_model_ver1.h5', compile=False)
except TypeError as e:
    print(f"Error loading LSTM model: {e}")
    # Handle the error or consider converting the model
